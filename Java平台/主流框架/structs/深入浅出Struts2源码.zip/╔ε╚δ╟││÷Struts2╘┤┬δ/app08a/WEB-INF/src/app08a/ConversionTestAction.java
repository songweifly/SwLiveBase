package app08a;

import com.opensymphony.xwork2.ActionSupport;

public class ConversionTestAction extends ActionSupport {
    private int age;
    public int getAge() {
        return age;
    }
    public void setAge(int age) {
        this.age = age;
    }
}
