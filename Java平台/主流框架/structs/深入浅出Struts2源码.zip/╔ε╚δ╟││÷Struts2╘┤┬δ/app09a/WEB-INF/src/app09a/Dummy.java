package app09a;

public interface Dummy {

}
