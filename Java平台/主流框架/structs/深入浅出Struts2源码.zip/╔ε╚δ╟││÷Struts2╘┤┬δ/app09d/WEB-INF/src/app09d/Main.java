package app09d;
import com.opensymphony.xwork2.ActionSupport;

public class Main extends ActionSupport {
}
