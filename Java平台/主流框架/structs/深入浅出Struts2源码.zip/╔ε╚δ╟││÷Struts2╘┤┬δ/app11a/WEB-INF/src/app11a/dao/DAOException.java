package app11a.dao;

public class DAOException extends Exception {

}
