package app05a;

import com.opensymphony.xwork2.ActionSupport;

public class ComboBoxTestAction extends ActionSupport {
    private String make;

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }
}


