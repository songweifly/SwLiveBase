package app06a;

import com.opensymphony.xwork2.ActionSupport;

public class ActionTestAction extends ActionSupport {

}
