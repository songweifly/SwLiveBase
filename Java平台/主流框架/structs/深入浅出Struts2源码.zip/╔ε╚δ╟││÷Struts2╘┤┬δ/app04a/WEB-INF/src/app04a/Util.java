package app04a;
import java.util.Date;

public class Util {
    public static Date now() {
        return new Date();
    }

}
