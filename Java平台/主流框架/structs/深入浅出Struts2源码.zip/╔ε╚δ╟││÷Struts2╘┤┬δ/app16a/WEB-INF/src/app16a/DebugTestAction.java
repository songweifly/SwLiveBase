package app16a;

import com.opensymphony.xwork2.ActionSupport;

public class DebugTestAction extends ActionSupport {

}
